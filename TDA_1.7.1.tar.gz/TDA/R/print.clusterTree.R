print.clusterTree <-
function(x, ...) {
  print(x)  
}