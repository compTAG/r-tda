print.maxPersistence <-
function(x, ...) {
  print(x)  
}